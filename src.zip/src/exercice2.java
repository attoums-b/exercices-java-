public class exercice2 {
    public static int[] initTableau(int n ){
        // pour fonctionner avec des tableaux de réels il faut modifier le type de la variable(en float ou en double)
        int[] tableau = new int[n];
        for(int i = 0; i < n ; i ++){
            tableau[i] = 0;

        }
        return tableau;
    }

    public static void afficheTableau(int[] tab){
        for (int j = 0 ; j < tab.length;j++){
            System.out.print(tab[j] + " ");
        }
        System.out.println();

    }

    public static int[] modifierTableau(int[] tab2){
        for (int j = 0 ; j < tab2.length;j++){
            tab2[j] = j*j;
        }
        return tab2;


    }

    public static int plusPetitElement(int[] tab){
        int min = tab[0];
        for (int j = 1 ; j < tab.length;j++){
           if (tab[j] < min){
               min = tab[j];
            }

        }
        return min;

    }





    public static void main(String[] args){
        int[] tableau = initTableau(4);
        afficheTableau(tableau);
        int[] modif = modifierTableau(tableau);
         afficheTableau(modif);
         int res = plusPetitElement(modif);
        System.out.println("le plus petit element de la liste est: " + res);

        }



    }


