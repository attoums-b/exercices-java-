import java.util.Scanner;
public class exercice1 {
    public static int lireEntier(int n) {
        return n;
    }
    public static int retournerCarre(int n){
        return n * n ;
    }

    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.print("entrez le nombre à lire: ");
        int n = scanner.nextInt();
        int entier = lireEntier(n);
        System.out.println(entier);
        int carre = retournerCarre(n);
        System.out.println("carré: "+ carre);
        scanner.close();
    }
}
